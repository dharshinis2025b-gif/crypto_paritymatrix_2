GHOST CHANNEL
A relay node leaked a burst of packets before going dark.
Everything we could salvage is in evidence/. The captured message is in encrypted/.
Find the flag. Format: CTF{...}
